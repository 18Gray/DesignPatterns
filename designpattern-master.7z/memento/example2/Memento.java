package cn.javass.dp.memento.example2;
/**
 * 备忘录的窄接口，没有任何方法定义
 */
public interface Memento {
	
}
