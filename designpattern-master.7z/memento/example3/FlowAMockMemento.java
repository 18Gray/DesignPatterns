package cn.javass.dp.memento.example3;
import java.io.*;
/**
 * 模拟运行流程A的对象的备忘录接口，是个窄接口
 */
public interface FlowAMockMemento extends java.io.Serializable{
	//空的
}
