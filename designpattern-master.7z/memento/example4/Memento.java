package cn.javass.dp.memento.example4;

public interface Memento {
	//空的
}
