package cn.javass.dp.abstractfactory.example5;

public class RdbMainDAOImpl implements OrderMainDAO{
	public void saveOrderMain() {
		System.out.println("now in RdbMainDAOImpl saveOrderMain");
	}
}
