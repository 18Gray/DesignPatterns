package cn.javass.dp.abstractfactory.example5;

public class RdbDetailDAOImpl implements OrderDetailDAO{
	public void saveOrderDetail() {
		System.out.println("now in RdbDetailDAOImpl saveOrderDetail");
	}
}
