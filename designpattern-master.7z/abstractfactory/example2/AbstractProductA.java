package cn.javass.dp.abstractfactory.example2;
/**
 * 抽象产品A的接口
 */
public interface AbstractProductA {
	//定义抽象产品A相关的操作
}

