package cn.javass.dp.abstractfactory.example2;

/**
 * 产品B的具体实现
 */
public class ProductB2 implements AbstractProductB {
	//实现产品B的接口中定义的操作
}

