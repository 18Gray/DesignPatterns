package cn.javass.dp.abstractfactory.example2;
/**
 * 抽象产品B的接口
 */
public interface AbstractProductB {
	//定义抽象产品B相关的操作
}

