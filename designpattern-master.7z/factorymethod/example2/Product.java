package cn.javass.dp.factorymethod.example2;
/**
 * 工厂方法所创建的对象的接口
 */
public interface Product {
	//可以定义Product的方法
}

