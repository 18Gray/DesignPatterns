package cn.javass.dp.factorymethod.example2;
/**
 * 具体的Product对象
 */
public class ConcreteProduct implements Product {
	//实现Product要求的方法
}