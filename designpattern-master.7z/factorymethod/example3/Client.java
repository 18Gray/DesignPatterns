package cn.javass.dp.factorymethod.example3;

public class Client {
	public static void main(String[] args) {
//		//创建需要使用的Creator对象
//		ExportOperate operate = new ExportXmlFileOperate();
//		//调用输出数据的功能方法
//		operate.export("测试数据");
		
//		ABC abc = new ExportOperate().createABC("cc");
		
//		abc.test();
	}
}
