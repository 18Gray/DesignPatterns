package cn.javass.dp.factorymethod.example5;

public interface Product {
	public void setProduct1(Product1 p1);
	public void setProduct2(Product2 p2);
}
