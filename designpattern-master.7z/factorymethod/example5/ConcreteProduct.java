package cn.javass.dp.factorymethod.example5;

public class ConcreteProduct implements Product{

	public void setProduct1(Product1 p1) {
		// TODO Auto-generated method stub
		
	}

	public void setProduct2(Product2 p2) {
		// TODO Auto-generated method stub
		
	}

}
