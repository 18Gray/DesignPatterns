package cn.javass.dp.factorymethod.example5;

public interface Product2{

}
