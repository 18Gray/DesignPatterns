package cn.javass.dp.factorymethod.example4;

public interface Product {

}
