package cn.javass.dp.factorymethod.example6;

public interface C1 {
	public void tc();
}
