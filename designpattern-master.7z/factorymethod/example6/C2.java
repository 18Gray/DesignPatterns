package cn.javass.dp.factorymethod.example6;

public class C2 implements C1{

	public void tc() {
		// TODO Auto-generated method stub
		
	}

}
