package cn.javass.dp.factorymethod.example6;

public interface C {
	public void tc();
}
