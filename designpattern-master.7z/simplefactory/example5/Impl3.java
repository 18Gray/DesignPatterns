package cn.javass.dp.simplefactory.example5;

public class Impl3 implements Api{
	
	public void test1(String s) {
		System.out.println("Now In Impl33333. The input s=="+s);
	}
}

