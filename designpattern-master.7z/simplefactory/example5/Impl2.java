package cn.javass.dp.simplefactory.example5;
/**
 * 对某个接口的一种实现 
 */
public class Impl2 implements Api{
	
	public void test1(String s) {
		System.out.println("Now In Impl222222. The input s=="+s);
	}
}
