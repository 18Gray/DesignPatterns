package cn.javass.dp.simplefactory;

public class MyUtil {
	private MyUtil(){
		
	}
	
	public static int myRandom(int min,int max){
		//...
		return 0;
	}
	public static int myRandom2(int min,int max){
		//...
		return 0;
	}
	public static int myRandom3(int min,int max){
		//...
		return 0;
	}
}
