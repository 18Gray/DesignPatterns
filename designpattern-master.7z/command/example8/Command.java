package cn.javass.dp.command.example8;

public interface Command {
	public void execute();
}
