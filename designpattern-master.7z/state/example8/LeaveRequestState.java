package cn.javass.dp.state.example8;

public interface LeaveRequestState extends State{
	//这里可以扩展跟自己流程相关的处理
}
