package cn.javass.dp.state.example8;

public class LeaveRequestContext extends StateMachine{
	//这里可以扩展跟自己流程相关的处理
}
